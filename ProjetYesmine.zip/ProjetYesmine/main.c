#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LONGUEUR_NOM_MAX 50

typedef struct NoeudCompte
{
    int numero_compte;
    char nom_client[LONGUEUR_NOM_MAX];
    float solde;
    struct NoeudCompte *suivant;
} NoeudCompte;

void ouvrirCompte(NoeudCompte **listeComptes)
{
    NoeudCompte *nouveauCompte = (NoeudCompte *)malloc(sizeof(NoeudCompte));
    if (nouveauCompte == NULL)
    {
        printf("Erreur lors de l'ouverture du compte.\n");
        return;
    }

    printf("Entrez le num�ro de compte : ");
    scanf("%d", &nouveauCompte->numero_compte);

    printf("Entrez le nom du client : ");
    while (getchar() != '\n')
        ;
    fgets(nouveauCompte->nom_client, sizeof(nouveauCompte->nom_client), stdin);
    nouveauCompte->nom_client[strcspn(nouveauCompte->nom_client, "\n")] = 0;

    printf("Entrez le solde initial : ");
    scanf("%f", &nouveauCompte->solde);

    nouveauCompte->suivant = *listeComptes;
    *listeComptes = nouveauCompte;
    printf("Compte ouvert avec succ�s.\n");
}

void afficherInfosCompte(NoeudCompte *listeComptes, int numCompte)
{
    while (listeComptes != NULL)
    {
        if (listeComptes->numero_compte == numCompte)
        {
            printf("Num�ro de compte : %d\n", listeComptes->numero_compte);
            printf("Nom du client : %s\n", listeComptes->nom_client);
            printf("Solde : %.3f DT \n ", listeComptes->solde);
            return;
        }
        listeComptes = listeComptes->suivant;
    }
    printf("Compte non trouv�.\n");
}
void mettreAJourInfosCompte(NoeudCompte *listeComptes, int numCompte)
{
    while (listeComptes != NULL)
    {
        if (listeComptes->numero_compte == numCompte)
        {
            printf("Quelle information voulez-vous mettre � jour pour le compte %d ?\n", numCompte);
            printf("1. Nom du client\n");
            printf("2. Solde\n");
            printf("Choix : ");
            int choix;
            scanf("%d", &choix);

            switch (choix)
            {
            case 1:
                printf("Entrez le nouveau nom du client : ");
                while (getchar() != '\n')
                    ;
                fgets(listeComptes->nom_client, sizeof(listeComptes->nom_client), stdin);
                listeComptes->nom_client[strcspn(listeComptes->nom_client, "\n")] = 0;
                printf("Nom du client mis � jour avec succ�s pour le compte %d.\n", numCompte);
                break;
            case 2:
                printf("Entrez le nouveau solde : ");
                float nouveauSolde;
                scanf("%f", &nouveauSolde);
                listeComptes->solde = nouveauSolde;
                printf("Solde mis � jour avec succ�s pour le compte %d.\n", numCompte);
                break;
            default:
                printf("Choix invalide.\n");
            }
            return;
        }
        listeComptes = listeComptes->suivant;
    }
    printf("Compte non trouv�.\n");
}

void transfertInterne(NoeudCompte *listeComptes, int compteSource, int compteDestination, float montant)
{
    NoeudCompte *source = NULL;
    NoeudCompte *destination = NULL;

    while (listeComptes != NULL)
    {
        if (listeComptes->numero_compte == compteSource)
        {
            source = listeComptes;
        }
        if (listeComptes->numero_compte == compteDestination)
        {
            destination = listeComptes;
        }
        listeComptes = listeComptes->suivant;
    }

    if (source != NULL && destination != NULL)
    {
        if (source->solde >= montant)
        {
            source->solde -= montant;
            destination->solde += montant;
            printf("Transfert de %.3f DT effectu� du compte %d au compte %d avec succ�s.\n", montant, compteSource, compteDestination);
        }
        else
        {
            printf("Solde insuffisant pour effectuer le transfert.\n");
        }
    }
    else
    {
        printf("Comptes source ou destination non trouv�s.\n");
    }
}

void fermerCompte(NoeudCompte **listeComptes, int numCompte)
{
    NoeudCompte *temp = *listeComptes;
    NoeudCompte *prev = NULL;

    while (temp != NULL && temp->numero_compte != numCompte)
    {
        prev = temp;
        temp = temp->suivant;
    }

    if (temp == NULL)
    {
        printf("Compte non trouv�.\n");
        return;
    }

    if (prev == NULL)
    {
        *listeComptes = temp->suivant;
    }
    else
    {
        prev->suivant = temp->suivant;
    }

    free(temp);
    printf("Compte ferm� avec succ�s.\n");
}

void afficherListeClients(NoeudCompte *listeComptes)
{
    if (listeComptes == NULL)
    {
        printf("Aucun client enregistr�.\n");
        return;
    }

    printf("Liste des clients :\n");
    while (listeComptes != NULL)
    {
        printf("%d. %s\n", listeComptes->numero_compte, listeComptes->nom_client);
        listeComptes = listeComptes->suivant;
    }
}

void effectuerDepot(NoeudCompte *listeComptes, int numCompte, float montant)
{
    while (listeComptes != NULL)
    {
        if (listeComptes->numero_compte == numCompte)
        {
            listeComptes->solde += montant;
            printf("D�p�t de %.3f DT effectu� avec succ�s sur le compte %d.\n", montant, numCompte);
            return;
        }
        listeComptes = listeComptes->suivant;
    }
    printf("Compte non trouv�.\n");
}

void effectuerRetrait(NoeudCompte *listeComptes, int numCompte, float montant)
{
    while (listeComptes != NULL)
    {
        if (listeComptes->numero_compte == numCompte)
        {
            if (listeComptes->solde >= montant)
            {
                listeComptes->solde -= montant;
                printf("Retrait de %.3f DT effectu� avec succ�s du compte %d.\n", montant, numCompte);
            }
            else
            {
                printf("Solde insuffisant pour effectuer le retrait.\n");
            }
            return;
        }
        listeComptes = listeComptes->suivant;
    }
    printf("Compte non trouv�.\n");
}

void donnerRating()
{
    printf("Merci de nous accorder quelques secondes pour noter notre service.\n");
    printf("Sur une �chelle de 1 � 5, quelle note donneriez-vous � notre application ?\n");

    int rating;
    printf("Votre note (1-5) : ");
    scanf("%d", &rating);

    if (rating >= 1 && rating <= 5)
    {
        printf("Merci pour votre �valuation ! Vous avez attribu� la note de %d sur 5.\n", rating);
    }
    else
    {
        printf("Note invalide. Veuillez saisir une note entre 1 et 5.\n");
    }
}

int main()
{
    NoeudCompte *listeComptes = NULL;
    int choix;

    FILE *fichier = fopen("comptes.txt", "r");
    if (fichier != NULL)
    {
        while (!feof(fichier))
        {
            NoeudCompte *nouveauCompte = (NoeudCompte *)malloc(sizeof(NoeudCompte));
            if (nouveauCompte == NULL)
            {
                printf("Erreur lors de la lecture des comptes.\n");
                return 1;
            }

            if (fscanf(fichier, "%d %s %f\n", &nouveauCompte->numero_compte, nouveauCompte->nom_client, &nouveauCompte->solde) == 3)
            {
                nouveauCompte->suivant = listeComptes;
                listeComptes = nouveauCompte;
            }
        }
        fclose(fichier);
    }

    do
    {
        printf("\n-----Welcome to E-Bank-----Founded by Yesmine Sellami----\n");
        printf("--1-- Voulez vous ouvrir un compte ? \n");
        printf("--2-- Voulez vous Afficher les d�tails d'un compte?\n");
        printf("--3-- Voulez vous Mettre � jour les informations d'un compte?\n");
        printf("--4-- Voulez vous Fermer un compte?\n");
        printf("--5-- Voulez vous Afficher la liste des clients?\n");
        printf("--6-- Voulez vous Gestion des transactions bancaires?\n");
        printf("--7-- Voulez vous Transfert entre comptes?\n");
        printf("--8-- Voulez vous Donner un rating � l'application?\n");
        printf("--9-- Quitter\n");
        printf("Entrez votre choix Monsieur/Madame : ");
        scanf("%d", &choix);

        switch (choix)
        {
        case 1:
            ouvrirCompte(&listeComptes);
            break;
        case 2:
        {
            int numCompte;
            printf("Entrez le num�ro de compte � afficher : ");
            scanf("%d", &numCompte);
            afficherInfosCompte(listeComptes, numCompte);
            break;
        }
        case 3:
        {
            int numCompte;
            printf("Entrez le num�ro de compte � mettre � jour : ");
            scanf("%d", &numCompte);
            mettreAJourInfosCompte(listeComptes, numCompte);
            break;
        }
        case 4:
        {
            int numCompte;
            printf("Entrez le num�ro de compte � fermer : ");
            scanf("%d", &numCompte);
            fermerCompte(&listeComptes, numCompte);
            break;
        }
        case 5:
            afficherListeClients(listeComptes);
            break;
        case 6:
        {
            int choixTransaction;
            printf("1. Effectuer un d�p�t\n");
            printf("2. Effectuer un retrait\n");
            printf("Tapez votre choix s'il vous pla�t : ");
            scanf("%d", &choixTransaction);

            int numCompte;
            float montant;
            switch (choixTransaction)
            {
            case 1:
                printf("Entrez le num�ro de compte pour le d�p�t : ");
                scanf("%d", &numCompte);
                printf("Entrez le montant du d�p�t : ");
                scanf("%f", &montant);
                effectuerDepot(listeComptes, numCompte, montant);
                break;
            case 2:
                printf("Entrez le num�ro de compte pour le retrait : ");
                scanf("%d", &numCompte);
                printf("Entrez le montant du retrait : ");
                scanf("%f", &montant);
                effectuerRetrait(listeComptes, numCompte, montant);
                break;
            default:
                printf("Choix invalide.\n");
            }
            break;
        }
        case 7:
        {
            int compteSource, compteDestination;
            float montantTransfert;
            printf("Entrez le num�ro de compte source : ");
            scanf("%d", &compteSource);
            printf("Entrez le num�ro de compte destination : ");
            scanf("%d", &compteDestination);
            printf("Entrez le montant � transf�rer : ");
            scanf("%f", &montantTransfert);
            transfertInterne(listeComptes, compteSource, compteDestination, montantTransfert);
            break;
        }
        case 8:
        {
            donnerRating();
            break;
        }
        case 9:
            printf("Merci d'avoir utilis� notre E-Bank.\n");
            break;
        default:
            printf("Choix invalide.\n");
        }
    } while (choix != 9);

    fichier = fopen("comptes.txt", "w");
    if (fichier != NULL)
    {
        NoeudCompte *temp = listeComptes;
        while (temp != NULL)
        {
            fprintf(fichier, "%d %s %.2f\n", temp->numero_compte, temp->nom_client, temp->solde);
            temp = temp->suivant;
        }
        fclose(fichier);
    }
    else
    {
        printf("Erreur lors de la sauvegarde des comptes.\n");
    }

    return 0;
}
